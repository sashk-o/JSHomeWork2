document.write("Завдання 3<br/><br/>");

let number = prompt("Введіть число");
let parsedNumber = parseInt(number);
let counter = 1;
let result = 1;
do{
    result *= counter;
    counter++;
} while (counter <= parsedNumber)

document.write("Факторіал введенного вами числа становить - ", result);