document.write("Завдання 4<br/><br/>");

let choice = prompt('Куди прямуєш - r/l/t/b');
let route = '';
while (choice !== null && (choice === 'r' || choice === 'l' || choice === 't' || choice === 'b')) {
    switch (choice) {
    case 'r':
        route += "направо<br/>";
        break;
    case 'l':
        route += "наліво<br/>";
        break;
    case 't':
        route += "вниз<br/>";
        break;
    case 'b':
        route += "вверх<br/>";
        break;
    default:
        break;
    }
    choice = prompt('Куди прямуєш - r/l/t/b');
}

if (route === '')
    route += "Маршрут не прокладено<br/>";
else
    route += "Маршрут складено<br/>";

document.write(route);