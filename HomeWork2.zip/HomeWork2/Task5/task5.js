document.write("Завдання 5<br/><br/>");

// прямокутник
let rectHeight=10;
let rectLength=50;
for (let i = 0; i < rectHeight; i++) {
    for (let j = 0; j < rectLength; j++){
        if (i==0 || i== rectHeight-1 || j == 0 || j == rectLength-1) 
            document.write('*');
        else 
            document.write('&nbsp&nbsp');
    }
    document.write("<br/>");
}
document.write("<br/><br/>");

//прямокутний трикутник
let trialHeight = 10;
let trialLength = 18;
for (let i = 0; i < trialHeight; i++) {
    if (i != 0) {
        document.write('*');
    }
    for (let j = 0; j < trialLength; j++){
        if (i == j || i == trialHeight-1) {
            document.write('*');
        }
        else 
        document.write('&nbsp&nbsp&nbsp&nbsp');
    }
    document.write("<br/>");
}
document.write("<br/><br/>");

//рівносторонній трикутник
let trialSide = 10;
for (let i = 0; i < trialSide; i++) {
    for (let j = trialSide; j > 0; j--){
        if (i == j ) {
            document.write('*');
        }
        else if (i == trialSide-1 && j != trialSide ){
            document.write('*');
        }
        else
            document.write('&nbsp&nbsp');
        }
        
        for (let j = 0; j < trialSide; j++){
            if (i == j ) {
                document.write('*');
            }
            else if (i == trialSide-1){
                document.write('*');
            }
            
            else
                document.write('&nbsp&nbsp');
            }
    document.write("<br/>");
}
document.write("<br/><br/>");

//ромб
let rhombusSide = 10;
for (let i = 0; i < rhombusSide; i++) {
    for (let j = rhombusSide; j > 0; j--){
        if (i == j ) {
            document.write('*');
        }
        else
            document.write('&nbsp&nbsp');
        }
        
        for (let j = 0; j < rhombusSide; j++){
            if (i == j ) {
                document.write('*');
            }
            else
                document.write('&nbsp&nbsp');
            }
    document.write("<br/>");
}
for (let i = rhombusSide; i >= 0; i--) {
    for (let j = rhombusSide; j > 0; j--){
        if (i == j ) {
            document.write('*');
        }
        else
            document.write('&nbsp&nbsp');
        }
        
        for (let j = 0; j <= rhombusSide; j++){
            if (i == j ) {
                document.write('*');
            }
            else
                document.write('&nbsp&nbsp');
            }
    document.write("<br/>");
}
document.write("<br/><br/>");