document.write("Завдання 2<br/><br/>");

let color = 'red';
let attempt;
let message;
let counter = 0;
while (counter < 5)
{
    if (counter != 4)
        attempt = prompt(`У вас ${counter+1} спроба. Вгадайте колір`);
    else
        attempt = prompt(`У вас ${counter+1} остання спроба. Вгадайте колір`);
    if (color === attempt)
    {
        message = `Вітаємо, ви вгадали із ${counter+1} спроби!`;
        break;
    }
    else
        message = "Ви не вгадали";
    counter++;
}

document.write(message);