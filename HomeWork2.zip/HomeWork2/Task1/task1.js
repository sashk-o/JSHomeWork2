document.write("Завдання 1<br/><br/>");

let result;
let a = prompt("Введіть перше число", 0);
let b = prompt("Введіть друге число", 0);

let parsedA = parseInt(a);
let parsedB = parseInt(b);

result = `Введені числа:<br/>Перше число - ${parsedA}.<br/>Друге число - ${parsedB}.
<br/><br/>Результат:<br/>`;

result += (parsedA + parsedB < 4) ? 'Мало' : 
(parsedA + parsedB > 100) ? 'Багато' : 'В самий раз';

document.write(result);